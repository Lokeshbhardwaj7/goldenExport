<?php
    date_default_timezone_set('Asia/Kolkata');

    if (time() > strtotime("08/22/2013 10:10AM"))
    {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Our Product Range - Golden Exports</title>
        <meta charset="utf-8">
        <link rel="icon" href="img/favicon.ico" type="image/x-icon">
        <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <!--CSS-->
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/touchTouch.css">
        <!--JS-->   
        <script src="js/jquery.js"></script>
        <script src="js/jquery-migrate-1.1.1.js"></script>
        <script src="js/superfish.js"></script>
        <script src="js/jquery.mobilemenu.js"></script>
        <script src="js/jquery.cookie.js"></script>
        <script src="js/jquery.easing.1.3.js"></script>
        <script src="js/jquery.ui.totop.js"></script>
        <script src="js/touchTouch.jquery.js"></script>
        <script>
         $(window).load(function() {
     // Initialize the gallery
     $('.thumb-pad5 figure a').touchTouch();
 });
</script>
<!--[if lt IE 8]>
        <div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
    <![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="js/html5shiv.js"></script>
<![endif]-->
</head>
<body>
    <div class="global">
        <header class="margBot1 margBrand">
            <div class="bg">
                <div class="container">
                    <div class="row">
                        <article class="span12">
                            <div class="navbar navbar_ clearfix marg">
                                <div class="navbar-inner">      
                                    <div class="clearfix">
                                        <div class="nav-collapse nav-collapse_">
                                            <ul class="nav sf-menu clearfix">
                                                <li><a href="index.php">home</a></li>
                                                <li><a href="company.php">company</a></li>
                                                <li class="active"><a href="products.php">products</a></li>
                                                <li><a href="quality.php">quality</a></li>
                                                <li><a href="contacts.php">contacts</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>                
                        </article>
                    </div>
                </div>
            </div>
        </header>
        <!--content-->
        <div class="container padBot">
            <div class="row">
                <article class="span4">
                    <h4 style="text-align:left">Product Range</h4>
                    <ol class="list5">
                        <li><i class="icon-ok"></i>&nbsp;<a href="raw_salt.php">Raw Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="industrial_salt.php">Industrial Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="edible_salt.php">Edible Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="salt_powder.php">Salt Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="crystal_salt.php">Crystal Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="dolomite.php">Dolomite Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="bentonite.php">Bentonite</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="calcite.php">Calcite Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="graphite.php">Graphite Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="talc.php">Talc Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="mica.php">Mica</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="zinc.php">Zinc Carbonate</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="walnut.php">Walnut Shell</a></li>

                        
                    </ol>
                </article>
                <article class="span8 about-box">
                    <h4 style="text-align:left">Mica Powder</h4>
                    <p><img src="img/mica-fine.jpg" width="350" height="150" align="left" style="padding:10px;"><br>Mica Powder is chemically inert, immune to climatic variations, non toxic, transparent and water proof. Mica is a naturally occurring stone mineral with shiny flakes which is its powdered form is known as mica powder. Therefore, mica powder is soft and sparkly like very fine glitter. It is used to give a metallic or shimmery pearl-like effect. As an element, mica is optically flat, translucent and elastic in nature.</p>

                    <div class="clearfix"></div><br>
                    <h3 style="text-align:left">The Followings Are General Characteristics Of Mica Powder:</h3>  
                    <ul>
                     <li>
                       It is highly inert to the action of light, heat electricity, water and other chemicals.
                   </li>
                   <li>
                       It transmits and reflects light and prevents penetration of sun rays, moisture, heat, gases etc. on the surface on which it's coated.
                   </li>
                   <li>
                      It has very high lubrication value thus used as High temperature grease, mould release etc., dusting surface and anti friction powder of compounds.
                  </li>
                  <li>
                      It has excellent di-electric & thermal insulation properties.
                  </li>
                  <li>
                      It produces lifting effects in liquid products due to low specific gravity and as such, remains uniformly dispersed over the surface of liquid vehicles.
                  </li>
                  <li>
                      It has very little abrasive effect and can easily get wetted by resin and dyes.
                  </li>
                  <li>
                      It has an excellent anti-sticking property and as such, during vulcanization, it prevents sticking and movement of sulphur, at the same time, it permits the air bubbles to escape
                  </li>
              </ul> 

              <h3 style="text-align:left">Mica- Coarse / Medium / Fine</h3>  

              

              

              
              <img src="img/mica_course.png" width="240" height="120" style="margin:5px;">
              <img src="img/mica_medium.png" width="240" height="120" style="margin:5px;">
              <img src="img/mica-fine.png" width="240" height="120" style="margin:5px;"><br><br>




              <h3 style="text-align:left">Chemical Analysis Of Dry Ground Mica Powder</h3>           
              <table class="table table-hover">

                  
                <tr>
                    <td>Alumina</td>
                    <td>(AL2O3)</td>
                    <td>23-40%</td>
                </tr>
                <tr>
                    <td>Silica</td>
                    <td>(SL2O3)</td>
                    <td>42-50%</td>
                  </tr>
                  <tr>
                    <td>Iron</td>
                    <td>(FE2O3)</td>
                    <td>1-5%</td>
                  </tr>
                  <tr>
                    <td >Potash</td>
                    <td >(K2O</td>
                    <td>7-9%</td>
                  </tr>
                  <tr>
                    <td>Calcium Oxide</td>
                    <td>(CAO)</td>
                    <td>0.21-0.35%</td>
                  </tr>
                  <tr>
                    <td>Magnesia</td>
                    <td>(MGO)</td>
                    <td>0.21-0.35%</td>
                  </tr>
                  <tr>
                    <td>Titanium Oxide</td>
                    <td>(TIO2)</td>
                    <td>TRACES</td>
                  </tr>
                  <tr>
                    <td>Sodium Oxide</td>
                    <td>(NA2O)</td>
                    <td>0.62-0.98%</td>
                  </tr>
                  <tr>
                    <td>Magnanese</td>
                    <td>(MNO2)</td>
                    <td>TRACES</td>
                  </tr>
                  <tr>
                    <td>Sulphar</td>
                    <td>(S)</td>
                    <td>TRACES</td>
                  </tr>
                  <tr>
                    <td>Phosophorus</td>
                    <td>(P)</td>
                    <td>0.02-0.03%</td>
                  </tr>
                  <tr>
                    <td>Moisture At 100C</td>
                    <td></td>
                    <td>0.10%</td>
                  </tr>
                  <tr>
                    <td>Loss of Ignition</td>
                    <td></td>
                    <td>03-05%</td>
                  </tr>
                </table>            


            </table>           

             <h3 style="text-align:left">Physical Properties Of Dry Ground Mica Powder</h3>           
              <table class="table table-hover">

                  
                <tr>
                    <td>Specific Gravity GM/CM3</td>
                    <td>2.80-2.85</td>
                    
                </tr>
                <tr>
                    <td>HARDNESS (MOSH SCALE)</td>
                    <td>2.5</td>
                  </tr>
                  <tr>
                    <td>PH</td>
                    <td>8</td>
                  </tr>
                  <tr>
                    <td>INSOLUBILITY HYDROCHLORIC ACID</td>
                    <td>94.00%</td>
                  </tr>
                  <tr>
                    <td>APP ARENT DENSITY 1BS/CU.FT.</td>
                    <td>12-SHP</td>
                  </tr>
                  <tr>
                    <td>WET BULKING VALUE GRAMS/1B</td>
                    <td>0.04257</td>
                  </tr>
                  <tr>
                    <td>OIL ABSORPTION (GM LINSEED OIL/100GM MICA)</td>
                    <td>45-50</td>
                  </tr>
                  <tr>
                    <td>SOLUBILITY IN WATER B/100ML</td>
                    <td>0.008</td>
                  </tr>
                  <tr>
                    <td>REFRACTIVE INDEX:</td>
                    <td>MIN-1.57 MAX-1.59</td>
                  </tr>
                  <tr>
                    <td>WHITENESS A. AMBER FILTER:</td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>B. GREEN FILTER</td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>C. BLUE FILTER</td>
                    <td>81</td>
                  </tr>
                  <tr>
                    <td>79</td>
                    <td></td>
                  </tr>
                  <tr>
                    <td>SOLUBILITY IN 10/00 ACETIC ACID, G/100ML</td>
                    <td>0.008</td>
                  </tr>
                  <tr>
                    <td>SOLUBILITY IN 50/00 ACETIC ACID, G/100ML</td>
                    <td>0.01</td>
                  </tr>
                </table>            


            </table>            
            
        </article>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="container">
        <div class="row">
            <article class="span12">
                <div class="row">
                    <nav class="span6">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li><a href="company.php">company</a></li>
                            <li class="active"><a href="products.php">products</a></li>
                            <li><a href="quality.php">quality</a></li>
                            <li><a href="contacts.php">contacts</a></li>
                        </ul>
                    </nav>
                    <div class="span3 offset3">
                        <p>goldenexports.co.in &copy; 2013</p>
                    </div>
                </div>
            </article>
            <!-- {%FOOTER_LINK} -->
        </div>
    </div>
</footer>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>

<?php } else { ?>
<HTML>
<HEAD><TITLE>Site Under Construction</TITLE>
  <link href="favicon.png" rel="shortcut icon" />
</HEAD>
<BODY BGCOLOR=#FFFFFF>
    <CENTER><BR><BR><BR><BR>
        <TABLE WIDTH=400 CELLPADDING=0 CELLSPACING=0 BORDER=0>
            <TR>
                <TD>
                    <BR><BR><BR>
                    <IMG SRC=img/cons.gif BORDER=0 ALIGN=right><FONT FACE=ARIAL SIZE=-1><B>This site is under construction.<BR>
                    Please visit again to check the status.</B> 
                    <FONT><I>Thanks!</I></FONT>
                    <BR><BR>
                    <IMG SRC=img/under.gif BORDER=0 WIDTH=442 HEIGHT=15>
                </TD>
            </TR>
        </TABLE>
    </CENTER>
</BODY>
</HTML> 

<?php } ?>