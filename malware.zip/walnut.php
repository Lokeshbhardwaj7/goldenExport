<?php
    date_default_timezone_set('Asia/Kolkata');

    if (time() > strtotime("08/22/2013 10:10AM"))
    {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Our Product Range - Golden Exports</title>
        <meta charset="utf-8">
        <link rel="icon" href="img/favicon.ico" type="image/x-icon">
        <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <!--CSS-->
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/touchTouch.css">
        <!--JS-->   
        <script src="js/jquery.js"></script>
        <script src="js/jquery-migrate-1.1.1.js"></script>
        <script src="js/superfish.js"></script>
        <script src="js/jquery.mobilemenu.js"></script>
        <script src="js/jquery.cookie.js"></script>
        <script src="js/jquery.easing.1.3.js"></script>
        <script src="js/jquery.ui.totop.js"></script>
        <script src="js/touchTouch.jquery.js"></script>
        <script>
         $(window).load(function() {
     // Initialize the gallery
     $('.thumb-pad5 figure a').touchTouch();
 });
</script>
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
    <![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="js/html5shiv.js"></script>
<![endif]-->
</head>
<body>
    <div class="global">
        <header class="margBot1 margBrand">
            <div class="bg">
                <div class="container">
                    <div class="row">
                        <article class="span12">
                            <div class="navbar navbar_ clearfix marg">
                                <div class="navbar-inner">      
                                    <div class="clearfix">
                                        <div class="nav-collapse nav-collapse_">
                                            <ul class="nav sf-menu clearfix">
                                                <li><a href="index.php">home</a></li>
                                                <li><a href="company.php">company</a></li>
                                                <li class="active"><a href="products.php">products</a></li>
                                                <li><a href="quality.php">quality</a></li>
                                                <li><a href="contacts.php">contacts</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>                
                        </article>
                    </div>
                </div>
            </div>
        </header>
        <!--content-->
        <div class="container padBot">
            <div class="row">
                <article class="span4">
                    <h4 style="text-align:left">Product Range</h4>
                    <ol class="list5">
                       <li><i class="icon-ok"></i>&nbsp;<a href="raw_salt.php">Raw Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="industrial_salt.php">Industrial Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="edible_salt.php">Edible Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="salt_powder.php">Salt Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="crystal_salt.php">Crystal Salt</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="dolomite.php">Dolomite Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="bentonite.php">Bentonite</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="calcite.php">Calcite Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="graphite.php">Graphite Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="talc.php">Talc Powder</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="mica.php">Mica</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="zinc.php">Zinc Carbonate</a></li>
                <li><i class="icon-ok"></i>&nbsp;<a href="walnut.php">Walnut Shell</a></li>
                        
                    </ol>
                </article>
                <article class="span8 about-box">
                    <h4 style="text-align:left">Walnut Shell</h4>
                    <p style="text-align:justify;"><img src="img/walnut.png" width="350" height="150" align="left" style="padding:10px;"><br>We are offering walnut shell. Walnut shell is utilized to control lost circulation in water oil base drilling fluids. It may be utilized by itself in re-circulated fluids or in pill form with fibrous flake material. A lost circulation material of ground nutshell is available in three grades, fine, medium, and coarse, ranging in size from 100 mesh to 6 mesh. Walnut shells are a versatile abrasive media widely used in blasting, tumbling, cleaning, polishing, filtration, cosmetics, as well as non-skid applications and filler applications. Walnut shells are crushed, ground and classified to standard mesh sizes that range from coarse grio fine powders.</p>
                    <div class="clearfix"></div><br>  
                    <article class="span8 about-box">

                        <a href="raw_salt.php"><img src="img/walnut1.png" width="240" height="120" style="margin:5px;"></a>
                        <a href="edible_salt.php"><img src="img/walnut2.png" width="240" height="120" style="margin:5px;"></a>
                        <a href="industrial_salt.php"><img src="img/walnut3.png" width="240" height="120" style="margin:5px;"></a>

                    </article><br>

                    <div class="clearfix"></div><br>  


                    <h4 style="text-align:left">Walnut Shell Medium</h4>
                    <p style="text-align:justify;"><img src="img/walnut-medium.jpg" width="350" height="150" align="left" style="padding:10px;"><br>Walnut shell media (Figure 1) is an all-natural, biodegradable, durable material with excellent strength characteristics. It has a specific gravity of 1.2-1.4 and a hardness of 3.5 MOH and 91 Rockwell.
                        Walnut shell performs well in a variety of pH and temperature conditions and are resistant to fermentation. They are reusable and reclaimable and thus serve as a suitable blast media in outdoor applications. Composition Materials has supplied walnut shell products globally for over 60 years.
                        Walnut Shell Blasting, In walnut shell blasting, wheel blast or air blast equipment is used to 
                    </p>
                    <p style="margin-top:-30px,  ;">remove paints and coatings from buildings, cars, boats, furniture, fiberglass, steel, etc. Walnut shell blasting offers the aggressiveness required to remove hard paints and coatings without damaging substrates. The process also enables selective coating removal, wherein the top coating can be removed without affecting the underlying coatings. In blast operations, a number of factors are involved and they include safety, nozzle distance, media particle size, and p.s.i. Walnut shell blasting does not cause silicosis and hence provides a perfect alternative to sandblasting. Walnut Shells for Deflashing, Polishing & Tumbling  Walnut shells are also used to deflash parts, as well as for tumbling and polishing brass, metal, plastics and hard rubber. In tumbling applications, a polishing compound is often mixed with the walnut shells.  </p>
                    <div class="clearfix"></div><br>  

                    <div class="clearfix"></div><br>  


                    <h4 style="text-align:left">Walnut Shell Flour</h4>
                    <p style="text-align:justify;"><img src="img/walnut.jpg" width="350" height="150" align="left" style="padding:10px;"><br>Ground walnut shell grits and flours are made for the construction, furniture, adhesives, paint, plywood, resin, rubber, paint and cosmetic industries. For anti-slip applications, ground walnut shell serves as a suitable additive for stairs, decks, pools, floors, and ramps. In addition, walnut shell flour is a preferred additive in rubber and plastics compound suppliers & exports. Moreover, walnut shells are employed in burn-out applications to improve porosity in ceramics.

                    </p>
                      




                </article>
            </div>
        </div>
    </div>
    <!--footer-->
    <footer>
        <div class="container">
            <div class="row">
                <article class="span12">
                    <div class="row">
                        <nav class="span6">
                            <ul>
                                <li><a href="index.php">home</a></li>
                                <li><a href="company.php">company</a></li>
                                <li class="active"><a href="products.php">products</a></li>
                                <li><a href="quality.php">quality</a></li>
                                <li><a href="contacts.php">contacts</a></li>
                            </ul>
                        </nav>
                        <div class="span3 offset3">
                            <p>goldenexports.co.in &copy; 2013</p>
                        </div>
                    </div>
                </article>
                <!-- {%FOOTER_LINK} -->
            </div>
        </div>
    </footer>
    <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>

<?php } else { ?>
<HTML>
<HEAD><TITLE>Site Under Construction</TITLE>
  <link href="favicon.png" rel="shortcut icon" />
</HEAD>
<BODY BGCOLOR=#FFFFFF>
    <CENTER><BR><BR><BR><BR>
        <TABLE WIDTH=400 CELLPADDING=0 CELLSPACING=0 BORDER=0>
            <TR>
                <TD>
                    <BR><BR><BR>
                    <IMG SRC=img/cons.gif BORDER=0 ALIGN=right><FONT FACE=ARIAL SIZE=-1><B>This site is under construction.<BR>
                    Please visit again to check the status.</B> 
                    <FONT><I>Thanks!</I></FONT>
                    <BR><BR>
                    <IMG SRC=img/under.gif BORDER=0 WIDTH=442 HEIGHT=15>
                </TD>
            </TR>
        </TABLE>
    </CENTER>
</BODY>
</HTML> 

<?php } ?>